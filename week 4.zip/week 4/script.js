const toggleSidebar = document.getElementById('toggleSidebar');
const sidebar = document.getElementById('sidebar');
const main = document.querySelector('main');

toggleSidebar.addEventListener('click', (e) => {
  e.stopPropagation(); 
  sidebar.classList.toggle('active');
});


document.addEventListener('click', (event) => {
  const isClickInsideSidebar = sidebar.contains(event.target);
  const isClickOnHamburger = toggleSidebar.contains(event.target);

  if (!isClickInsideSidebar && !isClickOnHamburger) {
    sidebar.classList.remove('active');
  }
});
